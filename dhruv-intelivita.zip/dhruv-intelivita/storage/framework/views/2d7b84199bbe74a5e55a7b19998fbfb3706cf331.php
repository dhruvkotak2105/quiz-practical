

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Edit Question')); ?></div>

                <div class="card-body">
                    <form action="<?php echo e(route('questions.update', $question)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="question_text">Question Text:</label>
                            <input type="text" id="question_text" name="question_text" value="<?php echo e(old('question_text', $question->question_text)); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="time_limit">Time Limit (seconds):</label>
                            <input type="number" id="time_limit" name="time_limit" value="<?php echo e(old('time_limit', $question->time_limit)); ?>" class="form-control" min="1">
                        </div>


                        <button type="submit" class="btn btn-primary">Update Question</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dhruv-intelivita\resources\views/questions/edit.blade.php ENDPATH**/ ?>