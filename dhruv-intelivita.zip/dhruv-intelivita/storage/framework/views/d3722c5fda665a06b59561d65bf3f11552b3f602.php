

<?php $__env->startSection('title', 'Create Question'); ?>

<?php $__env->startSection('content'); ?>
<h3>Create New Question</h3>

<form action="<?php echo e(route('questions.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div>
        <label for="question_text">Question Text:</label>
        <input type="text" id="question_text" name="question_text" placeholder="Enter your question here" required>
    </div>

    <div>
        <label for="time_limit">Time Limit (seconds):</label>
        <input type="number" id="time_limit" name="time_limit" placeholder="Enter time limit in seconds" min="1">
    </div>

    <button type="submit">Submit</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dhruv-intelivita\resources\views/questions/create.blade.php ENDPATH**/ ?>